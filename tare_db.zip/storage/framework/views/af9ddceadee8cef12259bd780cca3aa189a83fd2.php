

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Propiedads</h4>
            <p class="card-category">Lista de propiedads registrados en la base de datos</p>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12 text-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propiedad_create')): ?>
                <a href="<?php echo e(route('propiedads.create')); ?>" class="btn btn-sm btn-facebook">Añadir propiedad</a>
                <?php endif; ?>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table ">
                <thead class="text-primary">
                  <th> ID </th>
                  <th> Categoria </th>
                  
                  <th> Estado </th>
                  <th> Dirección </th>
                  <th> Estrato </th>
                  <th> Barrio </th>
                  <th> Ciudad </th>
                  
                  <th> Contactos </th>
                  
                  
                  
                  
                  
                  
                  <th> Nota </th>
                  <th> Observación</th>
                  
                  <th class="text-right"> Acciones </th>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $propiedads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propiedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <td><?php echo e($propiedad->id); ?></td>
                    <td><?php echo e($inmuebles[$propiedad->categoria-1]['categoria_inmueble']); ?></td>
                    
                    <td><?php echo e($estados[$propiedad->estado-1]['estado_propiedad']); ?></td>
                    <td><?php echo e($propiedad->direccion); ?></td>
                    <td><?php echo e($propiedad->estrato); ?></td>
                    <td><?php echo e($propiedad->barrio); ?></td>
                    <td><?php echo e($propiedad->ciudad); ?></td>
                    
                    <td><?php echo e($propiedad->contactos); ?></td>
                    
                    
                    
                    
                    
                    
                    <td>
                      <?php if($propiedad->nota): ?> <?php $__currentLoopData = $propiedad->nota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($value); ?>,
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                  </td>
                    <td><?php echo e($propiedad->observacion); ?></td>
                    <td class="td-actions text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propiedad_show')): ?>
                      <a href="<?php echo e(route('propiedads.show', $propiedad->id)); ?>" class="btn btn-info"> <i
                          class="material-icons">person</i> </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propiedad_edit')): ?>
                      <a href="<?php echo e(route('propiedads.edit', $propiedad->id)); ?>" class="btn btn-success"> <i
                          class="material-icons">edit</i> </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propiedad_destroy')): ?>
                      <form action="<?php echo e(route('propiedads.destroy', $propiedad->id)); ?>" method="post"
                        onsubmit="return confirm('¿Desea eliminar el registro?')" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" rel="tooltip" class="btn btn-danger">
                          <i class="material-icons">close</i>
                        </button>
                      </form>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                    <td colspan="2">Sin registros.</td>
                  </tr>
                  <?php endif; ?>
                </tbody>
              </table>
              
            </div>
          </div>
          <!--Footer-->
          <div class="card-footer mr-auto">
            <?php echo e($propiedads->links()); ?>

          </div>
          <!--End footer-->
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'propiedads', 'titlePage' => 'Propiedads'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/propiedads/index.blade.php ENDPATH**/ ?>