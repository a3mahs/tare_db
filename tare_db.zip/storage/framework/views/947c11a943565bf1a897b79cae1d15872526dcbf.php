<div class="sidebar" data-color="orange" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="https://www.aaarealestate.com.co" class="simple-text logo-normal">
      <?php echo e(__('TARE')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Bienvenidos')); ?></p>
        </a>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?>">
        
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'users' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
          <i class="material-icons">content_paste</i>
            <p>Usuarios</p>
        </a>
      </li>
      <?php endif; ?>
      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('propiedad_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'propiedads' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('propiedads.index')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Propiedades')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inmueble_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'inmuebles' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('inmuebles.index')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Categoria Inmueble')); ?></p>
        </a>
      </li>
      <?php endif; ?>
        
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('estado_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'estados' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('estados.index')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Estado Propiedad')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('documento_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'documentos' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('documentos.index')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Tipo Documentos')); ?></p>
        </a>
      </li>
      <?php endif; ?>

      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'posts' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('posts.index')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Post')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'permissions' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('permissions.index')); ?>">
          <i class="material-icons">bubble_chart</i>
          <p><?php echo e(__('Permisos')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_index')): ?>
      <li class="nav-item<?php echo e($activePage == 'roles' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
          <i class="material-icons">location_ons</i>
            <p><?php echo e(__('Roles')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      
    </ul>
  </div>
</div>
<?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>