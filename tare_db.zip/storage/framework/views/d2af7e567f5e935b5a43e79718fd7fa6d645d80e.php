<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <!--Header-->
          <div class="card-header card-header-primary">
            <h4 class="card-title">Estado</h4>
            <p class="card-category">Vista detallada de <?php echo e($estado->estado_propiedad); ?></p>
          </div>
          <!--End header-->
          <!--Body-->
          <div class="card-body">
            <div class="row">
              <!-- first -->
              <div class="col-md-4">
                <div class="card card-user">
                  <div class="card-body">
                    <p class="card-text">
                      <div class="author">
                        <div class="block block-one"></div>
                        <div class="block block-two"></div>
                        <div class="block block-three"></div>
                        <div class="block block-four"></div>
                        <a href="#">
                          <img class="avatar" src="<?php echo e(asset('/img/default-avatar.png')); ?>" alt="">
                          <h5 class="title mt-3">
                            <?php echo e(_('Detalles')); ?><br>
                          </h5>
                        </a>
                        <p class="description">
                          <?php echo e(_('ID Estado:')); ?> <?php echo e($estado->id); ?> <br>
                          <?php echo e(_('Estado:')); ?> <?php echo e($estado->estado_propiedad); ?> <br>
                          <?php echo e($estado->created_at); ?>

                        </p>
                      </div>
                    </p>
                  </div>
                  <div class="card-footer">
                    <div class="button-container">
                      <a href="<?php echo e(route('estados.index')); ?>" class="btn btn-sm btn-success mr-3"> Volver </a>
                      <a href="<?php echo e(route('estados.edit', $estado->id)); ?>" class="btn btn-sm btn-primary"> Editar </a>
                      
                    </div>
                  </div>
                </div>
              </div>
              <!--end first-->
            </div>
            <!--end row-->
          </div>
          <!--End card body-->
        </div>
        <!--End card-->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'estados', 'titlePage' => 'Detalles de los estados'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/estados/show.blade.php ENDPATH**/ ?>