<footer class="footer">
    <div class="container">
        
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, TODOS LOS DERECTOS -
            <a href="https://www.aaarealestate.com.co" target="_blank">TARE</a>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>