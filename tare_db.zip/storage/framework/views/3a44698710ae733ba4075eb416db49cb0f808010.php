<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <!--Header-->
          <div class="card-header card-header-primary">
            <h4 class="card-title">Propiedad</h4>
            <p class="card-category">Vista detallada de <?php echo e($propiedad->categoria); ?></p>
          </div>
          <!--End header-->
          <!--Body-->
          <div class="card-body">
            <div class="row">
              <!-- first -->
              <div class="col-md-4">
                <div class="card card-user">
                  <div class="card-body">
                    <p class="card-text">
                      <div class="author">
                        <div class="block block-one"></div>
                        <div class="block block-two"></div>
                        <div class="block block-three"></div>
                        <div class="block block-four"></div>
                        <a href="#">
                          <img class="avatar" src="<?php echo e(asset('/img/default-avatar.png')); ?>" alt="">
                          <h5 class="title mt-3">
                            <?php echo e(_('Propietario:')); ?> <?php echo e($propiedad->propietario); ?><br>
                            <?php echo e(_('Tipo de documento:')); ?> <?php echo e($documentos[$propiedad->tipo_documento-1]['documento_per']); ?><br>
                            <?php echo e(_('Número documento:')); ?> <?php echo e($propiedad->documento); ?> <br>
                            <?php echo e(_('Contacto propietario:')); ?> <?php echo e($propiedad->contactos_propietario); ?> <br>
                            <?php echo e(_('Dirección propietario:')); ?> <?php echo e($propiedad->direccion_propietario); ?> <br>
                            <?php echo e(_('Correo:')); ?> <?php echo e($propiedad->correo); ?> <br>
                          </h5>
                        </a>
                        <p class="description">
                          <?php echo e(_('ID Propiedad:')); ?> <?php echo e($propiedad->id); ?> <br>
                          <?php echo e(_('Tipo de propiedad:')); ?> <?php echo e($propiedad->inmueble->categoria_inmueble); ?> <br>
                          <?php echo e(_('Año:')); ?> <?php echo e($propiedad->construccion); ?> <br>
                          <?php echo e(_('Estado:')); ?> <?php echo e($estados[$propiedad->estado-1]['estado_propiedad']); ?> <br>
                          <?php echo e(_('Dirección:')); ?> <?php echo e($propiedad->direccion); ?> <br>
                          <?php echo e(_('Estrato:')); ?> <?php echo e($propiedad->estrato); ?> <br>
                          <?php echo e(_('Barrio:')); ?> <?php echo e($propiedad->barrio); ?> <br>
                          <?php echo e(_('Ciudad:')); ?> <?php echo e($propiedad->ciudad); ?> <br>
                          <?php echo e(_('Valor:')); ?> <?php echo e($propiedad->valor); ?> <br>
                          <?php echo e(_('Contacto:')); ?> <?php echo e($propiedad->contactos); ?> <br>                         
                          <?php echo e(_('Notas:')); ?> <?php $__currentLoopData = $propiedad->nota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($value); ?>,
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <br>
                          <?php echo e(_('Observaciones:')); ?> <?php echo e($propiedad->observacion); ?> <br>

                          <?php echo e($propiedad->created_at); ?>

                        </p>
                      </div>
                    </p>
                  </div>
                  <div class="card-footer">
                    <div class="button-container">
                      <a href="<?php echo e(route('propiedads.index')); ?>" class="btn btn-sm btn-success mr-3"> Volver </a>
                      <a href="<?php echo e(route('propiedads.edit', $propiedad->id)); ?>" class="btn btn-sm btn-primary"> Editar </a>
                      
                    </div>
                  </div>
                </div>
              </div>
              <!--end first-->
            </div>
            <!--end row-->
          </div>
          <!--End card body-->
        </div>
        <!--End card-->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['activePage' => 'propiedads', 'titlePage' => 'Detalles Propiedad'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/propiedads/show.blade.php ENDPATH**/ ?>