<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Posts</h4>
            <p class="card-category">Lista de posts registrados en la base de datos</p>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12 text-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_create')): ?>
                <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-sm btn-facebook">Añadir post</a>
                <?php endif; ?>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table ">
                <thead class="text-primary">
                  <th> ID </th>
                  <th> Nombre </th>
                  <th> Fecha de creación </th>
                  <th class="text-right"> Acciones </th>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td class="text-primary"><?php echo e($post->created_at->toFormattedDateString()); ?></td>
                    <td class="td-actions text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_show')): ?>
                      <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-info"> <i
                          class="material-icons">person</i> </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_edit')): ?>
                      <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-success"> <i
                          class="material-icons">edit</i> </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('post_destroy')): ?>
                      <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post"
                        onsubmit="return confirm('areYouSure')" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" rel="tooltip" class="btn btn-danger">
                          <i class="material-icons">close</i>
                        </button>
                      </form>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                    <td colspan="2">Sin registros.</td>
                  </tr>
                  <?php endif; ?>
                </tbody>
              </table>
              
            </div>
          </div>
          <!--Footer-->
          <div class="card-footer mr-auto">
            <?php echo e($posts->links()); ?>

          </div>
          <!--End footer-->
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'posts', 'titlePage' => 'Posts'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/posts/index.blade.php ENDPATH**/ ?>