

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Tipo Documento</h4>
            <p class="card-category">Lista de tipo de documento registrados en la base de datos</p>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12 text-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('documento_create')): ?>
                <a href="<?php echo e(route('documentos.create')); ?>" class="btn btn-sm btn-facebook">Añadir documento</a>
                <?php endif; ?>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table ">
                <thead class="text-primary">
                  <th> ID </th>
                  <th> Tipo Documento</th>
                  <th class="text-right"> Acciones </th>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <td><?php echo e($documento->id); ?></td>
                    <td><?php echo e($documento->documento_per); ?></td>
                    <td class="td-actions text-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('documento_show')): ?>
                      <a href="<?php echo e(route('documentos.show', $documento->id)); ?>" class="btn btn-info"> <i
                          class="material-icons">person</i> </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('documento_edit')): ?>
                      <a href="<?php echo e(route('documentos.edit', $documento->id)); ?>" class="btn btn-success"> <i
                          class="material-icons">edit</i> </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('documento_destroy')): ?>
                      <form action="<?php echo e(route('documentos.destroy', $documento->id)); ?>" method="post"
                        onsubmit="return confirm('¿Desea eliminar el registro?')" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" rel="tooltip" class="btn btn-danger">
                          <i class="material-icons">close</i>
                        </button>
                      </form>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                    <td colspan="2">Sin registros.</td>
                  </tr>
                  <?php endif; ?>
                </tbody>
              </table>
              
            </div>
          </div>
          <!--Footer-->
          <div class="card-footer mr-auto">
            <?php echo e($documentos->links()); ?>

          </div>
          <!--End footer-->
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'documentos', 'titlePage' => 'Documento'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/documentos/index.blade.php ENDPATH**/ ?>