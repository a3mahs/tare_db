<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="POST" action="<?php echo e(route('propiedads.update', $propiedad->id)); ?>" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="card">
                            <!--Header-->
                            <div class="card-header card-header-primary">
                                <h4 class="card-title">Editar propiedad</h4>
                                <p class="card-category">Editar datos del propiedad</p>
                            </div>
                            <!--End header-->
                            <!--Body-->
                            <div class="card-body">
                                <h6 class="card-subtitle mb-2 text-muted text-center">DATOS INMUEBLE</h6>
                                <div class="row">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-sm">
                                                <select class="form-control" name="categoria" required>
                                                    <option value="0">Tipo Inmueble</option>
                                                    <?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($propiedad->categoria == $inmueble['id']): ?>
                                                            <option value="<?php echo e($inmueble['id']); ?>" selected>
                                                                <?php echo e($inmueble['categoria_inmueble']); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($inmueble['id']); ?>">
                                                                <?php echo e($inmueble['categoria_inmueble']); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="construccion"
                                                    placeholder="Año"
                                                    value="<?php echo e(old('construccion', $propiedad->construccion)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm">
                                                <select class="form-control" name="estado" required>
                                                    <option value="0">Estado</option>
                                                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($propiedad->estado == $estado['id']): ?>
                                                            <option value="<?php echo e($estado['id']); ?>" selected>
                                                                <?php echo e($estado['estado_propiedad']); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($estado['id']); ?>">
                                                                <?php echo e($estado['estado_propiedad']); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="direccion"
                                                    placeholder="Dirección"
                                                    value="<?php echo e(old('direccion', $propiedad->direccion)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="barrio"
                                                    placeholder="Barrio/Zona"
                                                    value="<?php echo e(old('barrio', $propiedad->barrio)); ?>" autocomplete="off"
                                                    autofocus>
                                            </div>
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="estrato"
                                                    placeholder="Estrato" value="<?php echo e(old('estrato', $propiedad->estrato)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="ciudad"
                                                    placeholder="Ciudad" value="<?php echo e(old('ciudad', $propiedad->ciudad)); ?>"
                                                    autocomplete="off" autofocus required>
                                            </div>
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="valor"
                                                    placeholder="Valor" value="<?php echo e(old('valor', $propiedad->valor)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="contacto1"
                                                    placeholder="Contacto1"
                                                    value="<?php echo e(old('contacto1', $propiedad->contacto1)); ?>"
                                                    autocomplete="off" autofocus required>
                                            </div>
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="contacto2"
                                                    placeholder="Contacto2"
                                                    value="<?php echo e(old('contacto2', $propiedad->contacto2)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle mb-2 text-muted text-center">DATOS PRPIETARIO</h6>
                                <div class="row">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="propietario"
                                                    placeholder="Propietario"
                                                    value="<?php echo e(old('propietario', $propiedad->propietario)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                            <div class="col-sm">
                                                <select class="form-control" name="tipo_documento" required>
                                                    <option value="0">Tipo de Documento</option>
                                                    <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($propiedad->tipo_documento == $documento['id']): ?>
                                                            <option value="<?php echo e($documento['id']); ?>" selected>
                                                                <?php echo e($documento['documento_per']); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($documento['id']); ?>">
                                                                <?php echo e($documento['documento_per']); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="documento"
                                                    placeholder="Número"
                                                    value="<?php echo e(old('documento', $propiedad->documento)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="contacto1_propietario"
                                                    placeholder="Contacto1 de propietario"
                                                    value="<?php echo e(old('contacto1_propietario', $propiedad->contacto1_propietario)); ?>"
                                                    autocomplete="off" autofocus required>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="contacto2_propietario"
                                                    placeholder="Contacto2 de propietario"
                                                    value="<?php echo e(old('contacto2_propietario', $propiedad->contacto2_propietario)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="direccion_propietario"
                                                    placeholder="Dirección de propietario"
                                                    value="<?php echo e(old('direccion_propietario', $propiedad->direccion_propietario)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="correo"
                                                    placeholder="Correo" value="<?php echo e(old('correo', $propiedad->correo)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                            <div class="col-sm">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle mb-2 text-muted text-center">OBSERVACIONES</h6>
                                <div class="row">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-sm">
                                                <input type="text" class="form-control" name="observacion"
                                                    placeholder="Observación"
                                                    value="<?php echo e(old('observacion', $propiedad->observacion)); ?>"
                                                    autocomplete="off" autofocus>
                                            </div>
                                            <div class="col-sm">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End body-->
                            <!--Footer-->
                            <div class="card-footer ml-auto mr-auto">
                                <a href="<?php echo e(route('propiedads.index')); ?>" class="btn btn-success"> Volver
                                </a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                </div>
                <!--End footer-->
                </form>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['activePage' => 'propiedads', 'titlePage' => 'Editar Propiedad'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAHS\Documents\DEV\PROYECT\tare_db\resources\views/propiedads/edit.blade.php ENDPATH**/ ?>